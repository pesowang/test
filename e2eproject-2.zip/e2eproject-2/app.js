const express = require ('express')
const app = express()

app.get('/', (req, res) => res.send('Hello Wistron!/n11301301'))
app.listen (3000, () => console.log('server ready'))