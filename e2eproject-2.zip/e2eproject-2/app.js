const express = require ('express')
const app = express()

app.get('/', (req, res) => res.send('Hello Wistron!\nID:11301301\nName:Peter Wang'))
app.listen (3000, () => console.log('server ready'))